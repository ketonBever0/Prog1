import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

public class Csapat {

    private String neve;
    private Map<String, List<Jatekos>> jatekosok;
    private String poziciok;


    public Csapat(String neve) {
        this.neve = neve;
    }

    public String getNeve() {
        return neve;
    }

    public Map<String, List<Jatekos>> getJatekosok() {
        return jatekosok;
    }

    public void setJatekosok(Map<String, List<Jatekos>> jatekosok) {
        this.jatekosok = jatekosok;
    }

    public void beolvas(File fajlnev) {
        try {
            BufferedReader br = new BufferedReader(new FileReader(fajlnev));
            String sor = br.readLine();

            while (sor != null) {
                String[] mezok = sor.split(";");

                if (this.jatekosok.containsKey(mezok[1])) {
                    this.jatekosok.get(mezok[1]).add(new Jatekos(mezok[0], Integer.parseInt(mezok[2]), Integer.parseInt(mezok[3]), Integer.parseInt(mezok[4])));
                } else {
                    this.jatekosok.put(mezok[1], new ArrayList<>());
                    this.jatekosok.get(mezok[1]).add(new Jatekos(mezok[0], Integer.parseInt(mezok[2]), Integer.parseInt(mezok[3]), Integer.parseInt(mezok[4])));
                }

                sor = br.readLine();
            }
        } catch (IOException e) {
            System.err.println(Arrays.toString(e.getStackTrace()));
        }


    }

    public List<String> hianyzoPoziciok() {

        String[] osszes = new String[]{"Starting Pitcher", "First Baseman", "Shortstop", "Third Baseman", "Designated Hitter", "Catcher", "Second Baseman", "Relief Pitcher", "Outfielder"};
        List<String> kell = new ArrayList<>();
        for (String pozicio : osszes) {
            for (Map.Entry<String, List<Jatekos>> ez : this.jatekosok.entrySet()) {
                if (pozicio.equals(ez.getKey()) && !ez.getValue().isEmpty()) continue;
                else kell.add(ez.getKey());
            }
        }
        return kell;
    }

    public float atlag(String melyikAtlag) {
        if (!melyikAtlag.equals("magassag") && !melyikAtlag.equals("suly")) return 0;

        int ossz = 0, szam = 0;

        for (Map.Entry<String, List<Jatekos>> pozicio : this.jatekosok.entrySet()) {
            for (Jatekos jatekos : pozicio.getValue()) {
                if (melyikAtlag.equals("magassag")) {
                    ossz += jatekos.getMagassag();
                } else {
                    ossz += jatekos.getSuly();
                }
                szam++;
            }
        }
        return (float) ossz / szam;
    }
}
