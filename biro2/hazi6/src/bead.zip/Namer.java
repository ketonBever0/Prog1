public interface Namer {

    void rename(FileSystemEntry file);


}
