public class Main {
    public static void main(String[] args) {


        System.out.println(KovetelmenySzamito.teljesites(Double.parseDouble(args[0]), Double.parseDouble(args[1]), Double.parseDouble(args[2]), Double.parseDouble(args[3]), Double.parseDouble(args[4]), Integer.parseInt((args[5]))));


    }
}