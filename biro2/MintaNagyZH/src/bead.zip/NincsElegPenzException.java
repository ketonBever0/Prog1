public class NincsElegPenzException extends RuntimeException {

    public NincsElegPenzException(String message) {
        super(message);
    }
}
